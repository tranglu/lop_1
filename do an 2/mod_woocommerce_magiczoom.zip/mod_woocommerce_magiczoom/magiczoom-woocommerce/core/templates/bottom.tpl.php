<?php
if(!empty($magicscroll) && !empty($magicscrollOptions)) {
    $magicscrollOptions = " data-options=\"{$magicscrollOptions}\"";
} else {
    $magicscrollOptions = '';
}
?>
<!-- Begin magiczoom -->
<div class="MagicToolboxContainer selectorsBottom minWidth">
    <?php echo $main; ?>
<?php

if(is_array($thumbs)) {
    $thumbs = array_unique($thumbs);
}

if(count($thumbs) > 1) {
    ?>
    <div class="MagicToolboxSelectorsContainer">
        <div id="MagicToolboxSelectors<?php echo $pid ?>" class="<?php echo $magicscroll ?>"<?php echo $magicscrollOptions ?>>
        <?php echo join("\n\t", $thumbs); ?>
        </div>
    </div>
    <?php
}
 else {
    ?>
    <div class="MagicToolboxSelectorsContainer">
        <div id="MagicToolboxSelectors<?php echo $pid ?>" class="<?php echo $magicscroll ?>"<?php echo $magicscrollOptions ?>></div>
    </div>
    <?php
 }
?>
</div>
<!-- End magiczoom -->
