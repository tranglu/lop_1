#######################################################

 Magic Zoom™
 WooCommerce module version v6.8.10 [v1.6.86:v5.3.2]

 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2019 Magic Toolbox

#######################################################

INSTALLATION:

1. Upload the zip file via your WordPress admin area.

2. Activate Magic Zoom plugin for WooCommerce in the Plugins menu of WordPress.

3. Magic Zoom is ready to use!

4. To upgrade your version of Magic Zoom (which removes the "Please upgrade" text), buy Magic Zoom and overwrite the wp-content/plugins/magiczoom-woocommerce/magiczoom-woocommerce/core/magiczoom.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoom/

